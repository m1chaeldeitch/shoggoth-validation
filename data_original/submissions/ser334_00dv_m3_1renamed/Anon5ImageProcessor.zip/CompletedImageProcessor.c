/**
* Implementation of several functions to manipulate BMP files.
*
* Completion time: 
*
* @author XYZ
* @version
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "BMPHandler.h"
#include "Image.h"

//GLOBAL VARIABLES/MACROS
struct BMP_Header BMP;
struct DIB_Header DIB;
struct Image* image;
struct Pixel** pixels;

//FORWARD DECLARATIONS
void loadFile(FILE* input_file);
void writeFile(FILE* output_file);
void performOperations(int w, int r, int g, int b, float s);

int main(int argc, char** argv) {
    int option;
    int w_flag = 0, r_flag = 0, g_flag = 0, b_flag = 0, s_flag = 0, o_flag = 0; //ensuring each flag only appears once
    char *input_name, *output_name = ""; //strings for file names
    int r_shift = 0, g_shift = 0, b_shift = 0; //rgb values for color shift
    float s_value = 1; //value for image scaling

    input_name = argv[1];
    FILE *input_file = fopen(input_name, "rb");
    if (input_file == NULL) {
        printf("Input file does not exist!\n");
        exit(-1);
    }

    //Getting each flag from the command line and adding it to the list of operations
    while ((option = getopt(argc, argv, "wr:g:b:s:o:")) != -1) {
        switch (option) {
            case 'w' :
                if (w_flag == 0) {
                    w_flag++;
                } else {
                    printf("-w can only be entered once!\n");
                    exit(-1);
                }
                break;
            case 'r' :
                if (r_flag == 0) {
                    char* isInteger;
                    r_shift = (int) strtoll(optarg, &isInteger, 10);
                    if (*isInteger != '\0') {  //Checking if arg is not an integer
                        printf("-r arg is not an integer!\n");
                        exit(-1);
                    }
                    r_flag++;
                } else {
                    printf("-r can only be entered once!\n");
                    exit(-1);
                }
                break;
            case 'g' :
                if (g_flag == 0) {
                    char* isInteger;
                    g_shift = (int) strtoll(optarg, &isInteger, 10);
                    if (*isInteger != '\0') {  //Checking if arg is not an integer
                        printf("-g arg is not an integer!\n");
                        exit(-1);
                    }
                    g_flag++;
                } else {
                    printf("-g can only be entered once!\n");
                    exit(-1);
                }
                break;
            case 'b' :
                if (b_flag == 0) {
                    char* isInteger;
                    b_shift = (int) strtoll(optarg, &isInteger, 10);
                    if (*isInteger != '\0') {  //Checking if arg is not an integer
                        printf("-b arg is not an integer!\n");
                        exit(-1);
                    }
                    b_flag++;
                } else {
                    printf("-b can only be entered once!\n");
                    exit(-1);
                }
                break;
            case 's' :
                if (s_flag == 0) {
                    s_value = (float) strtod(optarg, &optarg);
                    s_flag++;
                } else {
                    printf("-s can only be entered once!\n");
                    exit(-1);
                }
                break;
            case 'o' :
                if (o_flag == 0) {
                    output_name = optarg;
                    o_flag++;
                } else {
                    printf("-o can only be entered once!\n");
                    exit(-1);
                }
                break;
            default :
                printf("Invalid args!\n");
                exit(-1);
        }
    }

    //Check if input file extension is of correct type (BMP)
    if (strstr(input_name, ".bmp") == NULL) {
        printf("Input file is not of the correct type!\n");
        exit(-1);
    }

    //Check if output file extension is of correct type (BMP)
    if (strcmp(output_name, "") != 0) {
        if (strstr(output_name, ".bmp") == NULL) {
            printf("Output file is not of the correct type!\n");
            exit(-1);
        }
    }

    //Redirect flow to create BMP and Image structs
    loadFile(input_file);
    fclose(input_file);

    //Redirect flow to perform operations
    performOperations(w_flag, r_shift, g_shift, b_shift, s_value);

    //Create output file
    FILE* output_file;
    if (strcmp(output_name, "") != 0) {
        output_file = fopen(output_name, "wb");
    } else { //If no output file specified, create "[input_name]_copy.bmp"
        input_name[strlen(input_name) - 4] = '\0';
        strcat(input_name, "_copy.bmp");
        output_file = fopen(input_name, "wb");
    }

    //Redirect flow to save/write to output file
    writeFile(output_file);
    fclose(output_file);
}

//Calls functions in BMPHandler and Image to create BMP and Image structs from input file
void loadFile(FILE* input_file) {
    readBMPHeader(input_file, &BMP);
    readDIBHeader(input_file, &DIB);

    pixels = (struct Pixel**) malloc(sizeof(struct Pixel*) * DIB.image_width);
    for (int p = 0; p < DIB.image_width; p++) {
        pixels[p] = (struct Pixel*) malloc(sizeof(struct Pixel) * DIB.image_height);
    }

    readPixelsBMP(input_file, pixels, DIB.image_width, DIB.image_height);
}

//Calls functions in BMPHandler and Image to write BMP and Image structs to output file
void writeFile(FILE* output_file) {
    writeBMPHeader(output_file, &BMP);
    writeDIBHeader(output_file, &DIB);
    writePixelsBMP(output_file, image_get_pixels(image),
                   image_get_width(image), image_get_height(image));
    image_destroy(&image);
}

//Calls functions in BMPHandler and Image to perform various operations on image
void performOperations(int w, int r, int g, int b, float s) {
    image = image_create(pixels, DIB.image_width, DIB.image_height);

    //Grayscale Check
    if (w == 1) {
        image_apply_bw(image);
    }

    //Color Shift Check
    if (r != 0 || g != 0 || b != 0) {
        image_apply_colorshift(image, r, g, b);
    }

    //Scale Check
    if (s != 1) {
        image_apply_resize(image, s);
        makeBMPHeader(&BMP, image_get_width(image), image_get_height(image));
        makeDIBHeader(&DIB, image_get_width(image), image_get_height(image));
    }
    makeDIBHeader(&DIB, image_get_width(image), image_get_height(image));
}
