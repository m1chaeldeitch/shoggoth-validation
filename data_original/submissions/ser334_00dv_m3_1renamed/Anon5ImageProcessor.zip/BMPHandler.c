/**
* Implementation of several functions to manipulate BMP files.
*
* Completion time:
*
* @author XYZ
* @version 
*/

#include <stdio.h>
#include <string.h>
#include "BMPHandler.h"

// FUNCTION IMPLEMENTATIONS
/**
 * Read BMP header of a BMP file.
 *
 * @param  file: A pointer to the file being read
 * @param  header: Pointer to the destination BMP header
 */
void readBMPHeader(FILE* file, struct BMP_Header* header) {
    //reading BMP data from file into struct
    fread(&(header->signature), sizeof(char) * 2, 1, file);
    fread(&(header->size), sizeof(int), 1, file);
    fread(&(header->reserved1), sizeof(short), 1, file);
    fread(&(header->reserved2), sizeof(short), 1, file);
    fread(&(header->offset_pixel_array), sizeof(int), 1, file);
}

/**
 * Write BMP header of a file. Useful for creating a BMP file.
 *
 * @param  file: A pointer to the file being written
 * @param  header: The header to write to the file
 */
void writeBMPHeader(FILE* file, struct BMP_Header* header) {
    //writing BMP data from struct into file
    fwrite(&(header->signature), sizeof(char) * 2, 1, file);
    fwrite(&(header->size), sizeof(int), 1, file);
    fwrite(&(header->reserved1), sizeof(short), 1, file);
    fwrite(&(header->reserved2), sizeof(short), 1, file);
    fwrite(&(header->offset_pixel_array), sizeof(int), 1, file);
}

/**
 * Read DIB header from a BMP file.
 *
 * @param  file: A pointer to the file being read
 * @param  header: Pointer to the destination DIB header
 */
void readDIBHeader(FILE* file, struct DIB_Header* header) {
    //reading DIB data from file into struct
    fread(&(header->dib_header_size), sizeof(int), 1, file);
    fread(&(header->image_width), sizeof(int), 1, file);
    fread(&(header->image_height), sizeof(int), 1, file);
    fread(&(header->planes), sizeof(short), 1, file);
    fread(&(header->bits_per_pixel), sizeof(short), 1, file);
    fread(&(header->compression), sizeof(int), 1, file);
    fread(&(header->image_size), sizeof(int), 1, file);
    fread(&(header->x_pixels_per_meter), sizeof(int), 1, file);
    fread(&(header->y_pixels_per_meter), sizeof(int), 1, file);
    fread(&(header->colors_in_color_table), sizeof(int), 1, file);
    fread(&(header->important_color_count), sizeof(int), 1, file);
}

/**
 * Write DIB header of a file. Useful for creating a BMP file.
 *
 * @param  file: A pointer to the file being written
 * @param  header: The header to write to the file
 */
void writeDIBHeader(FILE* file, struct DIB_Header* header) {
    //writing BMP data from struct into file
    fwrite(&(header->dib_header_size), sizeof(int), 1, file);
    fwrite(&(header->image_width), sizeof(int), 1, file);
    fwrite(&(header->image_width), sizeof(int), 1, file);
    fwrite(&(header->planes), sizeof(short), 1, file);
    fwrite(&(header->bits_per_pixel), sizeof(short), 1, file);
    fwrite(&(header->compression), sizeof(int), 1, file);
    fwrite(&(header->image_size), sizeof(int), 1, file);
    fwrite(&(header->x_pixels_per_meter), sizeof(int), 1, file);
    fwrite(&(header->y_pixels_per_meter), sizeof(int), 1, file);
    fwrite(&(header->colors_in_color_table), sizeof(int), 1, file);
    fwrite(&(header->important_color_count), sizeof(int), 1, file);
}

/**
 * Make BMP header based on width and height. Useful for creating a BMP file.
 *
 * @param  header: Pointer to the destination DIB header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makeBMPHeader(struct BMP_Header* header, int width, int height) {
    int padding = (3 * width) % 4; //calculate padding
    //allocate memory for the new BMP header
    struct BMP_Header* new_header = header;

    //update the struct variables to the new values
    strcpy(new_header->signature, SIGNATURE);
    new_header->size = 14 + 40 + (width * height * 3 + (height * padding));
    new_header->reserved1 = RESERVED_1;
    new_header->reserved2 = RESERVED_2;
    new_header->offset_pixel_array = 14 + 40;
}

/**
* Make new DIB header based on width and height.Useful for creating a BMP file.
*
* @param  header: Pointer to the destination DIB header
* @param  width: Width of the image that this header is for
* @param  height: Height of the image that this header is for
*/
void makeDIBHeader(struct DIB_Header* header, int width, int height) {
    int padding = (3 * width) % 4; //calculate padding
    //allocate memory for the new DIB header
    struct DIB_Header* new_header = header;

    //update the struct variables to the new values
    new_header->dib_header_size = 40;
    new_header->image_width = width;
    new_header->image_height = height;
    new_header->planes = PLANES;
    new_header->bits_per_pixel = 8 * 3;
    new_header->compression = COMPRESSION;
    new_header->image_size = (width * height * 3  + (height * padding));
    new_header->x_pixels_per_meter = HORIZONTAL_RES;
    new_header->y_pixels_per_meter = VERTICAL_RES;
    new_header->colors_in_color_table = COLOR_NUM;
    new_header->important_color_count = IMPORTANT_COLOR_NUM;
}

/**
 * Read Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read
 * @param  pArr: Pixel array to store the pixels being read
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
void readPixelsBMP(FILE* file, struct Pixel** pArr, int width, int height) {
    int padding = (3 * width) % 4; //calculate padding
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) { //order is BGR
            fread(&(pArr[(height - 1) - i][j].blue), sizeof(char), 1, file);
            fread(&(pArr[(height - 1) - i][j].green), sizeof(char), 1, file);
            fread(&(pArr[(height - 1) - i][j].red), sizeof(char), 1, file);
        }
        fseek(file, (long) sizeof(char) * padding, SEEK_CUR); //skip padding
    }
}

/**
 * Write Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image to write to the file
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
void writePixelsBMP(FILE* file, struct Pixel** pArr, int width, int height) {
    char c = 0;
    int padding = (width % 4); //calculate padding
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) { //order is BGR
            fwrite(&(pArr[(height - 1) - i][j].blue), sizeof(char), 1, file);
            fwrite(&(pArr[(height - 1) - i][j].green), sizeof(char), 1, file);
            fwrite(&(pArr[(height - 1) - i][j].red), sizeof(char), 1, file);
        }
        fwrite(&c, (long) sizeof(char) * padding, 1, file); //write padding
    }
}
