/**
* Implementation of several functions to manipulate an image.
*
* Completion time: 
*
* @author XYZ
* @version 
*/

#include <stdlib.h>
#include <string.h>
#include "Image.h"

// FUNCTION IMPLEMENTATIONS
/** Creates a new image and returns it.
*
 * @param  pArr: Pixel array of this image.
 * @param  width: Width of this image.
 * @param  height: Height of this image.
 * @return A pointer to a new image.
*/
Image* image_create(struct Pixel** pArr, int width, int height) {
    Image* img = (struct Image*) malloc(sizeof(struct Image));

    img->pArr = pArr;
    img->width = width;
    img->height = height;

    return img;
}

/** Destroys an image. Does not deallocate internal pixel array.
*
 * @param  img: the image to destroy.
*/
void image_destroy(Image** img) {
    free(*img);
    *img = NULL;
}

/** Returns a double pointer to the pixel array.
*
 * @param  img: the image.
*/
struct Pixel** image_get_pixels(Image* img) {
    return img->pArr;
}

/** Returns the width of the image.
*
 * @param  img: the image.
*/
int image_get_width(Image* img) {
    return img->width;
}

/** Returns the height of the image.
*
 * @param  img: the image.
*/
int image_get_height(Image* img) {
    return img->height;
}

/** Converts the image to grayscale.
*
 * @param  img: the image.
*/
void image_apply_bw(Image* img) {
    for (int i = 0; i < img->height; i++) {
        for (int j = 0; j < img->width; j++) { //calculate grayscale value at each pixel and update
            unsigned char grayscale = (unsigned char) ((0.299 * img->pArr[i][j].red) +
                    (0.587 * img->pArr[i][j].green) + (0.114 * img->pArr[i][j].blue));
            img->pArr[i][j].red = grayscale;
            img->pArr[i][j].green = grayscale;
            img->pArr[i][j].blue = grayscale;
        }
    }
}

/**
 * Shift color of the internal Pixel array. The dimension of the array is width * height.
 * The shift value of RGB is rShift, gShift，bShift. Useful for color shift.
 *
 * @param  img: the image.
 * @param  rShift: the shift value of color r shift
 * @param  gShift: the shift value of color g shift
 * @param  bShift: the shift value of color b shift
 */
void image_apply_colorshift(Image* img, int rShift, int gShift, int bShift) {
    for (int i = 0; i < img->height; i++) {
        for (int j = 0; j < img->width; j++) { //update each pixel by shift amounts
            //clamping for red
            if ((img->pArr[i][j].red + rShift) > 255) {
                img->pArr[i][j].red = 255;
            } else if ((img->pArr[i][j].red + rShift) < 0) {
                img->pArr[i][j].red = 0;
            } else {
                img->pArr[i][j].red += rShift;
            }
            //clamping for green
            if ((img->pArr[i][j].green + gShift) > 255) {
                img->pArr[i][j].green = 255;
            } else if ((img->pArr[i][j].green + gShift) < 0) {
                img->pArr[i][j].green = 0;
            } else {
                img->pArr[i][j].green += gShift;
            }
            //clamping for blue
            if ((img->pArr[i][j].blue + bShift) > 255) {
                img->pArr[i][j].blue = 255;
            } else if ((img->pArr[i][j].blue + bShift) < 0) {
                img->pArr[i][j].blue = 0;
            } else {
                img->pArr[i][j].blue += bShift;
            }
        }
    }
}

/** Converts the image to grayscale. If the scaling factor is less than 1 the new image will be
 * smaller, if it is larger than 1, the new image will be larger.
 *
 * @param  img: the image.
 * @param  factor: the scaling factor
*/
void image_apply_resize(Image* img, float factor) {
    //calculate new array's width and height
    int new_width = (int) ((float) img->width * factor);
    int new_height = (int) ((float) img->height * factor);

    //allocate new resized array
    struct Pixel** pixels = (struct Pixel**) malloc(sizeof(struct Pixel*) * new_width);
    for (int p = 0; p < new_width; p++) {
        pixels[p] = (struct Pixel*) malloc(sizeof(struct Pixel) * new_height);
    }

    //resize pixels into new array
    for (int i = 0; i < new_height; i++) {
        for (int j = 0; j < new_width; j++) { //calculate each pixel's nearest neighbor and update bgr
            int row_neighbor = (int) ((float) i / factor);
            int col_neighbor = (int) ((float) j / factor);
            pixels[i][j].blue = img->pArr[row_neighbor][col_neighbor].blue;
            pixels[i][j].green = img->pArr[row_neighbor][col_neighbor].green;
            pixels[i][j].red = img->pArr[row_neighbor][col_neighbor].red;
        }
    }

    //Set to the new array and deallocate the old one
    struct Pixel** tmp = img->pArr;
    img->pArr = pixels;
    free(tmp);

    //Update width and length of image
    img->width = new_width;
    img->height = new_height;
}
