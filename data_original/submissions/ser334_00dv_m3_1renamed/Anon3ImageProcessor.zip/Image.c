/**
* Specification for an image ADT.
*
* Completion time:
*
* @author XYZ
* @version 
*/

#include <stdio.h>
#include <stdlib.h>
#include "BMPHandler.h"
#include "Image.h"


/* Creates a new image and returns it.
*
 * @param  pArr: Pixel array of this image.
 * @param  width: Width of this image.
 * @param  height: Height of this image.
 * @return A pointer to a new image.
*/
Image* image_create(struct Pixel** pArr, int width, int height){
    struct Image* img = (struct Image*) malloc(sizeof(struct Image));
    img->height = height;
    img->width = width;
    img->pArr = pArr;
    return img;
}


/* Destroys an image. Does not deallocate internal pixel array.
*
 * @param  img: the image to destroy.
*/
void image_destroy(Image** img){
    free(img);
}

/* Returns a double pointer to the pixel array.
*
 * @param  img: the image.
*/
struct Pixel** image_get_pixels(Image* img){
    return img->pArr;
}

/* Returns the width of the image.
*
 * @param  img: the image.
*/
int image_get_width(Image* img){
    return img->width;
}

/* Returns the height of the image.
*
 * @param  img: the image.
*/
int image_get_height(Image* img){
    return img->height;
}

/* Converts the image to grayscale.
*
 * @param  img: the image.
*/
void image_apply_bw(Image* img){

    for(int row = 0; row < img->height; row++){
        for(int col = 0; col < img->width; col++){
//            printf("[%d],[%d],[%d] ->",img->pArr[row][col].red,img->pArr[row][col].green,
//                   img->pArr[row][col].blue);

            int gray = img->pArr[row][col].red * 0.299 + img->pArr[row][col].green * 0.587 +
                            img->pArr[row][col].blue * 0.114;

            img->pArr[row][col].red = (unsigned char) gray;
            img->pArr[row][col].blue = (unsigned char) gray;
            img->pArr[row][col].green = (unsigned char) gray;

//            printf("{[%d],[%d],[%d]\n",img->pArr[row][col].red,img->pArr[row][col].green,
//                   img->pArr[row][col].blue);
        }
    }
}

/**
 * Shift color of the internal Pixel array. The dimension of the array is width * height.
 * The shift value of RGB is rShift, gShift，bShift. Useful for color shift.
 *
 * @param  img: the image.
 * @param  rShift: the shift value of color r shift
 * @param  gShift: the shift value of color g shift
 * @param  bShift: the shift value of color b shift
 */
void image_apply_colorshift(Image* img, int rShift, int gShift, int bShift){
    for(int row = 0; row < img->height; row++){
        for(int col = 0; col < img->width; col++){

//            printf("[%d],[%d],[%d] ->",img->pArr[row][col].red,img->pArr[row][col].green,
//                   img->pArr[row][col].blue);

            int red = img->pArr[row][col].red + rShift;
            int green = img->pArr[row][col].green  + gShift;
            int blue = img->pArr[row][col].blue + bShift;

            if(red > 255)   red = 255;
            if(green > 255) green = 255;
            if(blue > 255)  blue = 255;

            if(red < 0)     red = 0;
            if(green < 0)   green = 0;
            if(blue < 0)    blue = 0;

            img->pArr[row][col].red = (unsigned char) red;
            img->pArr[row][col].green = (unsigned char) green;
            img->pArr[row][col].blue = (unsigned char) blue;

//            printf("[%d],[%d],[%d]\n",img->pArr[row][col].red,img->pArr[row][col].green,
//                   img->pArr[row][col].blue);
        }
    }
}

/* If the scaling factor is less than 1 the new image will be
 * smaller, if it is larger than 1, the new image will be larger.
 *
 * Doesn't free old pixel data, since that would cause a dangling pointer to pixel[] array
 *
 * @param  img: the image.
 * @param  factor: the scaling factor
*/
void image_apply_resize(Image* img, float factor){

    int newWidth = img->width * factor;
    int newHeight = img->height * factor;

    struct Pixel** pixels = (struct Pixel**) malloc(sizeof(struct Pixel*) * newHeight);
    for(int p = 0; p < newHeight; p++){
        pixels[p] = (struct Pixel*) malloc(sizeof(struct Pixel) * newWidth);
    }

    int oldRow,oldCol;

    for(int row = 0; row < newHeight; row++){
        for(int col = 0; col < newWidth; col++){
            oldRow = (int) (row / factor);
            oldCol = (int) (col / factor);
            pixels[row][col] = img->pArr[oldRow][oldCol];
        }
    }

    for(int i = 0; i < img->height; i++){
        free(img->pArr[i]);
        img->pArr[i] = NULL;
    }
    free(img->pArr);

    img->pArr = pixels;
    img->width = newWidth;
    img->height = newHeight;
}