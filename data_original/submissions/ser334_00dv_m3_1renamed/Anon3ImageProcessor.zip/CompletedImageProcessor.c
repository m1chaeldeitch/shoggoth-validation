/**
* Parses command line input and acts according to it
*
* Completion time: 
*
* @author XYZ
* @version 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "BMPHandler.h"
#include "Image.h"

int main(int argc, char** argv) {
    printf("Processing your request...\n");
    int rShift = 0;
    int gShift = 0;
    int bShift = 0;
    float scale = 1.0;
    int grayScale = 0;
    char* fileName = argv[optind];
    char* newFileName = NULL;

    int opt;

    printf("\tInput File:\t%s\n",fileName);

    while( (opt = getopt(argc,argv,"r:g:b:s:wo:"))  != -1){
        switch(opt){
            case 'r':
                rShift = atoi(optarg);
                printf("\tRed Shift: \t%d\n",rShift);
                break;
            case 'b':
                bShift = atoi(optarg);
                printf("\tBlue Shift:  \t%d\n",bShift);
                break;
            case 'g':
                gShift = atoi(optarg);
                printf("\tGreen Shift \t%d\n",gShift);
                break;
            case 'w':
                printf("\tGray Scale: \tEnabled\n");
                grayScale = 1;
                break;
            case 's':
                scale = atof(optarg);
                printf("\tScale: \t\t%f\n",scale);
                break;
            case 'o':
                if(optarg) {
                    newFileName = optarg;
                    printf("\tOutput File\t%s\n", newFileName);
                }
                else {
                    printf("\tOutput File:\tOutput.bmp\n");
                 }
                break;
        }
    }

    if(newFileName == NULL){
//        newFileName = strdup("Output1.bmp");
        strcat(newFileName,"copy_");
        strcat(newFileName,fileName);
    }

    //Creating file
    FILE* file = fopen(fileName, "rb");
    struct BMP_Header bmp_header;
    struct DIB_Header dib_header;

    if(file == NULL){
        printf("Unable to load specified file\n");
        exit(1);
    }

    //reading headers
    readBMPHeader(file, &bmp_header);
    readDIBHeader(file,&dib_header);

    //making pixel array
    struct Pixel** pixels = (struct Pixel**) malloc(sizeof(struct Pixel*) * dib_header.imageHeight);
    for(int p = 0; p < dib_header.imageHeight;p++){
        pixels[p] = (struct Pixel*) malloc(sizeof(struct Pixel) * dib_header.imageWidth);
    }

    //reading pixel data
    readPixelsBMP(file,pixels,dib_header.imageWidth,dib_header.imageHeight);

    //creating img
    struct Image* img = image_create(pixels,dib_header.imageWidth,dib_header.imageHeight);

    //creating output file
    FILE* outputFile = fopen(newFileName, "wb");

    //Making BMP Header
    struct BMP_Header newBMP;
    makeBMPHeader(&newBMP, dib_header.imageWidth * scale, dib_header.imageHeight * scale);

    //Making DIB Header
    struct DIB_Header newDIB;
    makeDIBHeader(&newDIB, dib_header.imageWidth * scale, dib_header.imageHeight * scale);

    //Applying hue shift
    if(rShift != 0 || gShift != 0 || bShift != 0){
        image_apply_colorshift(img,rShift,gShift,bShift);
    }

    //Applying grayscale
    if(grayScale == 1){
        image_apply_bw(img);
    }

    //Resizing Pixel Array
    if(scale != 1.0) {
        image_apply_resize(img, scale);
    }

    //Writing BMP Header to Output File
    writeBMPHeader(outputFile, &newBMP);

    //Writing DIB Header File
    writeDIBHeader(outputFile, &newDIB);


    //Writing Pixels to Output File
    writePixelsBMP(outputFile, image_get_pixels(img), newDIB.imageWidth, newDIB.imageHeight);

    //Closing file streams
    fclose(outputFile);
    fclose(file);

    //Deleting malloc memory
//    for(int p = 0; p < dib_header.imageWidth; p++){
//        free(pixels[p]);
//    }
//    free(pixels);

    for(int i = 0; i < newDIB.imageHeight;i++){
        free(img->pArr[i]);
        img->pArr[i] = NULL;
    }
    free(img);

    return 0;
}