/**
* Implementation of several functions to manipulate BMP files.
*
* Completion time: 
*
* @author XYZ
* @version 
*/

#include <stdio.h>
#include "BMPHandler.h"
#include "Image.h"



/**
 * Read BMP header of a BMP file.
 *
 * @param  file: A pointer to the file being read
 * @param  header: Pointer to the destination BMP header
 */
void readBMPHeader(FILE* file, struct BMP_Header* header){

    fread(&header->signature,sizeof(char)*2,1,file);
    fread(&header->size,sizeof(int),1,file);
    fread(&header->reserved1,sizeof(short),1,file);
    fread(&header->reserved2,sizeof(short),1,file);
    fread(&header->pixelOffset,sizeof(int),1,file);

//    printf("Signature \t%c%c\n",header->signature[0],header->signature[1]);
//    printf("Size\t\t%d\n",header->size);
//    printf("Reserved1\t%d\n",header->reserved1);
//    printf("Reserved2\t%d\n",header->reserved2);
//    printf("Pxl Offset\t%d\n",header->pixelOffset);
}

/**
 * Write BMP header of a file. Useful for creating a BMP file.
 *
 * @param  file: A pointer to the file being written
 * @param  header: The header to write to the file
 */
void writeBMPHeader(FILE* file, struct BMP_Header* header){
    fwrite(&header->signature,sizeof(char)*2,1,file);
    fwrite(&header->size,sizeof(int),1,file);
    fwrite(&header->reserved1,sizeof(short),1,file);
    fwrite(&header->reserved2,sizeof(short),1,file);
    fwrite(&header->pixelOffset,sizeof(int),1,file);
}

/**
 * Read DIB header from a BMP file.
 *
 * @param  file: A pointer to the file being read
 * @param  header: Pointer to the destination DIB header
 */
void readDIBHeader(FILE* file, struct DIB_Header* header){
    fread(&header->headerSize,sizeof(int),1,file);
    fread(&header->imageWidth,sizeof(int),1,file);
    fread(&header->imageHeight,sizeof(int),1,file);
    fread(&header->planes,sizeof(short),1,file);
    fread(&header->bitPerPixel,sizeof(short),1,file);
    fread(&header->compression,sizeof(int),1,file);
    fread(&header->imageSize,sizeof(int),1,file);
    fread(&header->yPixelMeter,sizeof(int),1,file);
    fread(&header->xPixelMeter,sizeof(int),1,file);
    fread(&header->colorTable,sizeof(int),1,file);
    fread(&header->colourCount,sizeof(int),1,file);

//    printf("Header size \t%d\n",header->headerSize);
//    printf("Image width \t%d\n",header->imageWidth);
//    printf("Image height \t%d\n",header->imageHeight);
//    printf("Planes \t\t\t%d\n",header->planes);
//    printf("Bits per Pixel \t%d\n",header->bitPerPixel);
//    printf("Compression \t%d\n",header->compression);
//    printf("Image Size \t\t%d\n",header->imageSize);
//    printf("Y Pixel Meter \t%d\n",header->yPixelMeter);
//    printf("X Pixel meter \t%d\n",header->xPixelMeter);
//    printf("Colour Table \t%d\n",header->colorTable);
//    printf("Colour Count \t%d\n",header->colourCount);
}

/**
 * Write DIB header of a file. Useful for creating a BMP file.
 *
 * @param  file: A pointer to the file being written
 * @param  header: The header to write to the file
 */
void writeDIBHeader(FILE* file, struct DIB_Header* header){
    fwrite(&header->headerSize, sizeof(int), 1, file);
    fwrite(&header->imageWidth,sizeof(int),1,file);
    fwrite(&header->imageHeight,sizeof(int),1,file);
    fwrite(&header->planes,sizeof(short),1,file);
    fwrite(&header->bitPerPixel,sizeof(short),1,file);
    fwrite(&header->compression,sizeof(int),1,file);
    fwrite(&header->imageSize,sizeof(int),1,file);
    fwrite(&header->yPixelMeter,sizeof(int),1,file);
    fwrite(&header->xPixelMeter,sizeof(int),1,file);
    fwrite(&header->colorTable,sizeof(int),1,file);
    fwrite(&header->colourCount,sizeof(int),1,file);
}

/**
 * Make BMP header based on width and height. Useful for creating a BMP file.
 *
 * @param  header: Pointer to the destination DIB header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makeBMPHeader(struct BMP_Header* header, int width, int height){
    header->signature[0] = 'B';
    header->signature[1] = 'M';
    header->size = ( (int)sizeof(struct DIB_Header) ) + 14 + ((width * 24 / 32) * 4 * height);
    header->reserved1 = 0;
    header->reserved2 = 0;
    header->pixelOffset = sizeof(struct DIB_Header) + 14;

}

/**
* Make new DIB header based on width and height.Useful for creating a BMP file.
*
* @param  header: Pointer to the destination DIB header
* @param  width: Width of the image that this header is for
* @param  height: Height of the image that this header is for
*/
void makeDIBHeader(struct DIB_Header* header, int width, int height){
    header->headerSize = sizeof(struct DIB_Header);
    header->imageWidth = width;
    header->imageHeight = height;
    header->planes = 1;
    header->bitPerPixel = sizeof(struct Pixel) * 8;
    header->compression = 0;
    header->imageSize = (width * 24 / 32) * 4 * height;
    header->yPixelMeter = 3780;
    header->xPixelMeter = 3780;
    header->colorTable = 0;
    header->colourCount = 0;
}

/**
 * Read Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read
 * @param  pArr: Pixel array to store the pixels being read
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
void readPixelsBMP(FILE* file, struct Pixel** pArr, int width, int height){
    int padding = (width * 3) % 4;


    for(int row = 0; row < height; row++){
//        printf("{");
        for(int col = 0; col < width; col++){
            fread(&pArr[row][col].red,sizeof(char),1,file);
            fread(&pArr[row][col].green,sizeof(char),1,file);
            fread(&pArr[row][col].blue,sizeof(char),1,file);

//            printf("[%d,",pArr[row][col].red);
//            printf("%d,",pArr[row][col].green);
//            printf("%d],",pArr[row][col].blue);

        }
//        printf("}\n");
        if(padding != 0){
            fseek(file,padding ,SEEK_CUR);
        }

    }
}

/**
 * Write Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image to write to the file
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
void writePixelsBMP(FILE* file, struct Pixel** pArr, int width, int height){
    int padding = (width * 3) % 4;
    char pad[4] = {0};


    for(int row = 0; row < height; row++){
        for(int col = 0; col < width; col++){
            fwrite(&pArr[row][col].red,sizeof(char),1,file);
            fwrite(&pArr[row][col].green,sizeof(char),1,file);
            fwrite(&pArr[row][col].blue,sizeof(char),1,file);
        }
        if(padding != 0){
            fwrite((const void *) pad,sizeof(char),padding,file);
        }

    }
}
