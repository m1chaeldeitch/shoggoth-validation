/**
* BMPHandler program
*
* Completion time: 12 hours
*
* @author XYZ
* @version 
*/


#include <stdio.h>
#include <stdlib.h>
#include "Image.h"




void readBMPHeader(FILE* file, struct BMP_Header* header)
{
    fread(&header->signature, sizeof(char)*2, 1, file);
    fread(&header->size, sizeof(int), 1, file);
    fread(&header->reserved1, sizeof(short), 1, file);
    fread(&header->reserved2, sizeof(short), 1, file);
    fread(&header->offset_pixel_array, sizeof(int), 1, file);
}

void writeBMPHeader(FILE* file, struct BMP_Header* header)
{
    fwrite(&header->signature, sizeof(char)*2, 1, file);
    fwrite(&header->size, sizeof(int), 1, file);
    fwrite(&header->reserved1, sizeof(short), 1, file);
    fwrite(&header->reserved2, sizeof(short), 1, file);
    fwrite(&header->offset_pixel_array, sizeof(int), 1, file);
}


void readDIBHeader(FILE* file, struct DIB_Header* header)
{

    fread(&header->DIB_Header_Size, sizeof(int),1, file);
    fread(&header->iw, sizeof(int), 1, file);
    fread(&header->ih, sizeof(int), 1, file);
    fread(&header->Planes, sizeof(short), 1, file);
    fread(&header->BPS, sizeof(short), 1, file);
    fread(&header->Comp, sizeof(int), 1, file);
    fread(&header->ImagSz, sizeof(int), 1, file);
    if (header->ImagSz == 0)
    {
        header->ImagSz = header->ih * ((header->iw * 3 + (header->iw % 4)));
    }
    fread(&header->XPM, sizeof(int), 1, file);
    if (header->XPM != 0)
    {
        header->XPM = 0;
    }
    fread(&header->YPM, sizeof(int), 1, file);
    if (header->YPM != 0)
    {
        header->YPM = 0;
    }
    fread(&header->ColorsInColorTable, sizeof(int), 1, file);
    fread(&header->ImportantCC, sizeof(int), 1, file);
}

void writeDIBHeader(FILE* file, struct DIB_Header* header)
{


    fwrite(&header->DIB_Header_Size, sizeof(int),1, file);
    fwrite(&header->iw, sizeof(int), 1, file);
    fwrite(&header->ih, sizeof(int), 1, file);
    fwrite(&header->Planes, sizeof(short), 1, file);
    fwrite(&header->BPS, sizeof(short), 1, file);
    fwrite(&header->Comp, sizeof(int), 1, file);
    fwrite(&header->ImagSz, sizeof(int), 1, file);
    fwrite(&header->XPM, sizeof(int), 1, file);
    fwrite(&header->YPM, sizeof(int), 1, file);
    fwrite(&header->ColorsInColorTable, sizeof(int), 1, file);
    fwrite(&header->ImportantCC, sizeof(int), 1, file);

}

void makeBMPHeader(struct BMP_Header* header, int width, int height)
{
    int padded_width = 4 * ((width * 3 + 3) / 4);
    header->signature[0] = 'B';
    header->signature[1] = 'M';

    header->size = padded_width * height;
    header->reserved1 = 0;
    header->reserved2 = 0;
    header->offset_pixel_array = 54;

}

void makeDIBHeader(struct DIB_Header* header, int width, int height)
{
    header->DIB_Header_Size=40;
    header->iw = width;
    header->ih = height;
    header->Planes = 1;
    header->BPS = 24;
    header->Comp = 0;
    header->ImagSz = height * ((width * 3 + (width % 4)));
    header->XPM = 3780;
    header->YPM = 3780;
    header->ColorsInColorTable = 0;
    header->ImportantCC = 0;

}

void readPixelsBMP(FILE* file, struct Pixel** pArr, int width, int height)
{
    int padding = (4 - (width * 3) % 4) % 4;

    for (int h = 0; h < height; h++)
    {
        for(int w = 0; w<width; w++)
        {
            unsigned char b;
            unsigned char g;
            unsigned char r;

            fread(&b, sizeof(unsigned char), 1, file);
            fread(&g, sizeof(unsigned char), 1, file);
            fread( &r, sizeof(unsigned char), 1, file);

            pArr[h][w].blue = b;
            pArr[h][w].green = g;
            pArr[h][w].red = r;
            if (padding > 0)
            {
                fseek(file, padding, SEEK_CUR);
            }
        }
    }

}


void writePixelsBMP(FILE* file, struct Pixel** pArr, int width, int height)
{

    int padding = (4 - (width * 3) % 4) % 4;

    for (int h = 0; h < height; h++)
    {
        for(int w = 0; w<width; w++)
        {

            fwrite(&pArr[h][w].blue, sizeof(unsigned char), 1, file);
            fwrite(&pArr[h][w].green, sizeof(unsigned char), 1, file);
            fwrite( &pArr[h][w].red, sizeof(unsigned char), 1, file);


        }
        for (int i = 0; i < padding; i++)
        {
            unsigned char zero = 0;
            fwrite(&zero, sizeof(unsigned char), 1, file);
        }
    }

}