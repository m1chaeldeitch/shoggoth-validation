/**
* Image processor program
*
* Completion time:
*
* @author  XYZ
* @version 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "BMPHandler.h"
#include "Image.c"
#include "BMPHandler.c"

int main(int argc, char* argv[])
{

    struct BMP_Header BMP;
    struct DIB_Header DIB;



    FILE* file_input = fopen(argv[1], "rb");
    readBMPHeader(file_input, &BMP);
    readDIBHeader(file_input, &DIB);
    fseek(file_input, BMP.offset_pixel_array, SEEK_SET);

    struct Pixel** pixels = (struct Pixel**)malloc(sizeof(struct Pixel*) * DIB.ih);
    for (int p = 0; p < DIB.ih; p++) {
        pixels[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * DIB.iw);
    }
    readPixelsBMP(file_input, pixels, DIB.iw, DIB.ih);

    if (argc < 4)
    {
        printf("Not enough arguments passed.\n");
        printf("Usage: ImageProcessor <filename> [-w] [-s <scale>] [-o <outputfilename>] [-r <redShift>] [-g <greenShift>] [-b <blueShift>]\n");
        return 1;
    }

    // get the filename
    char* filename = argv[1];
    int redShift =0;
    int greenShift = 0;
    int blueShift = 0;
    int bw = 1;
    int scaleFlag = 1;
    float scale = 0.0;
    char* outputFile = "output.bmp";

    // parse the command line arguments
    for (int i = 2; i < argc; i++)
    {
        if (strcmp(argv[i], "-r") == 0)
        {
            redShift = atoi(argv[++i]);
        }
        else if (strcmp(argv[i], "-g") == 0)
        {
            greenShift = atoi(argv[++i]);
        }
        else if (strcmp(argv[i], "-b") == 0)
        {
            blueShift = atoi(argv[++i]);
        }
        else if (strcmp(argv[i], "-w") == 0)
        {
            bw = 0;
        }
        else if (strcmp(argv[i], "-s") == 0)
        {
            scale = atof(argv[++i]);
            scaleFlag = 0;
        }
        else if(strcmp(argv[i], "-o") == 0)
        {
            outputFile = argv[++i];
        }
    }

    // load the image



    Image* img = image_create(pixels, DIB.iw, DIB.ih);
    if (bw == 0)
    {
        image_apply_bw(img);
    }
    image_apply_colorshift(img, redShift, greenShift, blueShift);
    if (scaleFlag == 0)
    {
        image_apply_resize(img, scale);
    }




    makeBMPHeader(&BMP, image_get_width(img), image_get_height(img));
    makeDIBHeader(&DIB, image_get_width(img), image_get_height(img));



    FILE* file_output = fopen(outputFile, "wb");
    writeBMPHeader(file_output, &BMP);
    writeDIBHeader(file_output, &DIB);
    writePixelsBMP(file_output, image_get_pixels(img), image_get_width(img), image_get_height(img));

    fclose(file_output);
    image_destroy(&img);

}


