//
// Created by XYZ
//

#include <stdio.h>
#include <stdlib.h>
#include "Image.h"

Image* image_create(struct Pixel** pArr, int width, int height)
{
    struct Image* pic = malloc(sizeof(struct Image));
    pic->pArr = pArr;
    pic->height = height;
    pic->width = width;

    return pic;
}

void image_destroy(Image** img)
{

    free((*img)->pArr);
    free(*img);
    *img = NULL;
}

struct Pixel** image_get_pixels(Image* img)
{
    return img->pArr;
}

int image_get_width(Image* img)
{
    return img->width;
}

int image_get_height(Image* img)
{
    return img->height;
}

void image_apply_bw(Image* img)
{
    for(int w=0; w<img->width; w++)
    {
        for(int h=0; h<img->height; h++)
        {
            int gray = (int)(0.299*img->pArr[w][h].red + 0.587*img->pArr[w][h].green + 0.114*img->pArr[w][h].blue);
            img->pArr[w][h].red = gray;
            img->pArr[w][h].green = gray;
            img->pArr[w][h].blue = gray;

        }
    }
};


void image_apply_colorshift(Image* img, int rShift, int gShift, int bShift)
{

    for(int w = 0; w<img->width; w++)
    {
        for(int h = 0; h<img->height; h++)
        {


            ///green
            if(img->pArr[w][h].green + gShift > 255)
            {
                img->pArr[w][h].green = 255;
            }
            else if(img->pArr[w][h].green + gShift < 0)
            {
                img->pArr[w][h].green = 0;
            }
            else
            {
                img->pArr[w][h].green+=gShift;
            }
            ///red
            if(img->pArr[w][h].red + rShift > 255)
            {
                img->pArr[w][h].red = 255;
            }
            else if(img->pArr[w][h].red + rShift < 0)
            {
                img->pArr[w][h].red = 0;
            }
            else
            {
                img->pArr[w][h].red+=rShift;
            }

            ///blue
            if(img->pArr[w][h].blue + bShift > 255)
            {
                img->pArr[w][h].blue = 255;
            }
            else if(img->pArr[w][h].blue + bShift < 0)
            {
                img->pArr[w][h].blue = 0;
            }
            else
            {
                img->pArr[w][h].blue+=bShift;
            }
        }
    }


}

void image_apply_resize(Image* img, float factor)
{
    int newWidth = (int)(img->width * factor);
    int newHeight = (int)(img->height * factor);

    struct Pixel** newPixels = (struct Pixel**)malloc(newHeight*sizeof(struct Pixel*));
    for(int i = 0; i < newHeight; i++)
    {
        newPixels[i] = (struct Pixel*)malloc(newWidth * sizeof(struct Pixel));
    }

    for (int i = 0; i < newHeight; i++)
    {
        int row = (int)(i / factor); //calculating to the nearest number in that row
        for (int j = 0; j < newWidth; j++)
        {
            int col = (int)(j / factor); //calculating to the nearest number in that column
            newPixels[i][j] = img->pArr[row][col];
        }
    }
    free(img->pArr);
    img->pArr = newPixels;
    img->width = newWidth;
    img->height = newHeight;
}
