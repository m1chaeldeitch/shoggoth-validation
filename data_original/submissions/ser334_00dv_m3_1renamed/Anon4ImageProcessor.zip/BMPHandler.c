//INCLUDES//
#include <stdio.h>
#include "BMPHandler.h"
#include "Image.h"

#include <string.h>

//FUNCTIONALITY//
void readBMPHeader(FILE* file, struct BMP_Header* header) {
    // file is already open for reading (rb)
    fread(&header->signature, sizeof(char)*2, 1, file);
    fread(&header->fileSize, sizeof(int), 1, file);
    fread(&header->reserved1, sizeof(char)*2, 1,file);
    fread(&header->reserved2, sizeof(char)*2, 1,file);
    fread(&header->offsetToPixArray, sizeof(int), 1, file);
}

void writeBMPHeader(FILE* file, struct BMP_Header* header) {
    fwrite(&header->signature, sizeof(char)*2, 1, file);
    fwrite(&header->fileSize, sizeof(int), 1, file);
    fwrite(&header->reserved1, sizeof(char)*2, 1,file);
    fwrite(&header->reserved2, sizeof(char)*2, 1,file);
    fwrite(&header->offsetToPixArray, sizeof(int), 1, file);
}

void readDIBHeader(FILE* file, struct DIB_Header* header) {
    fread(&header->DIBHeaderSize, sizeof(int), 1, file);
    fread(&header->imageWidth, sizeof(int), 1, file);
    fread(&header->imageHeight, sizeof(int), 1, file);
    fread(&header->planes, sizeof(char)*2, 1, file);
    fread(&header->bitsPerPixel, sizeof(char)*2, 1, file);
    fread(&header->compression, sizeof(int), 1, file);
    fread(&header->imageSize, sizeof(int), 1, file);
    fread(&header->xPixPerMeter, sizeof(int), 1, file);
    fread(&header->yPixPerMeter, sizeof(int), 1, file);
    fread(&header->colorsInColorTable, sizeof(int), 1, file);
    fread(&header->importantColorCount, sizeof(int), 1, file);
}

void writeDIBHeader(FILE* file, struct DIB_Header* header) {
    fwrite(&header->DIBHeaderSize, sizeof(int), 1, file);
    fwrite(&header->imageWidth, sizeof(int), 1, file);
    fwrite(&header->imageHeight, sizeof(int), 1, file);
    fwrite(&header->planes, sizeof(char)*2, 1, file);
    fwrite(&header->bitsPerPixel, sizeof(char)*2, 1, file);
    fwrite(&header->compression, sizeof(int), 1, file);
    fwrite(&header->imageSize, sizeof(int), 1, file);
    fwrite(&header->xPixPerMeter, sizeof(int), 1, file);
    fwrite(&header->yPixPerMeter, sizeof(int), 1, file);
    fwrite(&header->colorsInColorTable, sizeof(int), 1, file);
    fwrite(&header->importantColorCount, sizeof(int), 1, file);
}

void makeBMPHeader(struct BMP_Header* header, int width, int height) {
    strcpy(header->signature, "BM"); //TODO: Check if this works correctly
    header->reserved1 = 0;
    header->reserved2 = 0;
    header->offsetToPixArray = 54; // TODO Check if this is always correct

    // Left to calculate filesize
    //      File Size = 14 (BMP header)
    //                + 40 (DIB header)
    //                + (imageWidth + padding) * (image height)

    int numBitsInRow = width * 24;
    int bytesPerRow = numBitsInRow / 8;
    int numPaddingBytes;

    if ((width * 3) % 4 == 0) {
        numPaddingBytes= 0;
    } else {
        numPaddingBytes = 4 - ((width * 3) % 4);
    }

    bytesPerRow += numPaddingBytes;

    int imageSize = (bytesPerRow * height);
    header->fileSize = 54 + imageSize;

}

void makeDIBHeader(struct DIB_Header* header, int width, int height) {
    header->DIBHeaderSize = 40;   //For SER334 Specifically
    header->imageWidth = width;
    header->imageHeight = height;
    header->planes = 1;
    header->bitsPerPixel = 24;    // For Ser334 specifically
    header->compression = 0;
    header->xPixPerMeter = 3780;
    header->yPixPerMeter = 3780;
    header->colorsInColorTable = 0;
    header->importantColorCount = 0;

    //extra work needed for image size
    int numBitsInRow = width * 24;
    int bytesPerRow = numBitsInRow / 8;
    int numPaddingBytes;

    if ((width * 3) % 4 == 0) {
        numPaddingBytes= 0;
    } else {
        numPaddingBytes = 4 - ((width * 3) % 4);
    }

    bytesPerRow += numPaddingBytes;

    int imageSize = (bytesPerRow * height);
    header->imageSize = imageSize;
}




/* NOTE: Intended functionality in driver is to:
 *      (1) Open a file
 *      (2) Create headers
 *      (3) Read pixels
 *      (4) Close file
 * Main point here is that the current byte being looked at will transfer across
 * different functions (I think)
 * */


// pixels[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * 152);
// Above line is when pixels is a **. Makes me think that we can do pArr[x]...
// TODO: Check above statement for validity.

void readPixelsBMP(FILE* file, struct Pixel** pArr, int width, int height) {
    // Reading FROM a file, INTO a pixel array whose address is stored in pArr
    // GIVEN a specific width and height

    // pArr = address of pixelArray
    // *pArr can be addressed in array notation (I think).


    int numPaddingBytes;
    if ((width * 3) % 4 == 0) {
        numPaddingBytes= 0;
    } else {
        numPaddingBytes = 4 - ((width * 3) % 4);
    }
    // struct Pixel** copyParr = pArr;
    //
    // for (int r = 0; r < height; r++) {
    //     struct Pixel* currRow = copyParr[r];
    //     for (int c = 0; c < width; c++) {      //C++ reference xD
    //         struct Pixel currPixel = currRow[c];
    //         fread(&currPixel.blue, sizeof(char), 1, file);
    //         fread(&currPixel.green, sizeof(char), 1, file);
    //         fread(&currPixel.red, sizeof(char), 1, file);
    //     }
    //     fseek(file, sizeof(char) * numPaddingBytes, SEEK_CUR); // Then skip by padding
    // }


    for (int  i = 0; i < height; i++) {   //For the height of the image
        for (int j = 0; j < width; j++) { //Read the entire width of pixels
            //Create a pixel struct from file (no need to malloc, as we can do so before
            fread(&pArr[i][j].blue, sizeof(char), 1, file);
            fread(&pArr[i][j].green, sizeof(char), 1, file);
            fread(&pArr[i][j].red, sizeof(char), 1, file);
            int test = 0;
        }
        fseek(file, sizeof(char) * numPaddingBytes, SEEK_CUR); // Then skip by padding
        //TODO: Check to make sure that it isn't (padding -1)
    }
}

void writePixelsBMP(FILE* file, struct Pixel** pArr, int width, int height) {
    //int numPaddingBytes = (width * 3) % 4;
    int numPaddingBytes;
    if ((width * 3) % 4 == 0) {
        numPaddingBytes= 0;
    } else {
        numPaddingBytes = 4 - ((width * 3) % 4);
    }
    char paddingVal = '\000';


    for (int  i = 0; i < height; i++) {   //For the height of the image
        for (int j = 0; j < width; j++) { //Read the entire width of pixels
            //Create a pixel struct from file (no need to malloc, as we can do so before
            fwrite(&pArr[i][j].blue, sizeof(char), 1, file);
            fwrite(&pArr[i][j].green, sizeof(char), 1, file);
            fwrite(&pArr[i][j].red, sizeof(char), 1, file);
        }
        fwrite(&paddingVal, sizeof(char) * numPaddingBytes, 1, file);
        //TODO: This might get wonky
    }
}