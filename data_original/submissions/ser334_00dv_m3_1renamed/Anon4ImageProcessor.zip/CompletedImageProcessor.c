////////////////////////////////////////////////////////////////////////////////
//INCLUDES
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "BMPHandler.h"
#include "Image.h"

int main(int argc, char* argv[]) {
     // int argc = 6; //program name will count as an argv
     // char* argv[6];
     // argv[0] = "./Homework_Base";
     // argv[1] = "ttt.bmp";
     // argv[2] = "-o";
     // argv[3] = "ttt_testingInvalidRGB.bmp";
     // argv[4] = "-r";
     // argv[5] = "-300";
    // argv[6] = "-g";
    // argv[7] = "45";
    // argv[8] = "-o";
    // argv[9] = "filtered1.bmp";

    //Prepare for operations
    struct BMP_Header BMP;
    struct DIB_Header DIB;

    FILE* file_input = fopen(argv[1], "rb");
    if (file_input == NULL) {
        printf("%s not found.", argv[1]);
        return 1;
    }

    readBMPHeader(file_input, &BMP);
    readDIBHeader(file_input, &DIB);

    //Create pixel array and image from input file
    struct Pixel** pixels = malloc(sizeof(struct Pixel*) * DIB.imageHeight); // height
    for (int p = 0; p < DIB.imageHeight; p++) {
        pixels[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * DIB.imageWidth); //width
    }
    readPixelsBMP(file_input, pixels, DIB.imageWidth, DIB.imageHeight);
    Image* img = image_create(pixels, DIB.imageWidth, DIB.imageHeight);


    //Handle user specified input
    int needToGray = 0;
    int blueShift = 0;
    int greenShift = 0;
    int redShift = 0;
    double scale = 1.0;

    char outputFileName[255];         //255 used for max length of a file name
    char tempName[255];
    strcpy(tempName, argv[1]);
    char* token;
    char* rest = tempName;
    token = strtok_r(rest, ".", &rest);
    strcpy(outputFileName, token);
    strcat(outputFileName, "_copy.bmp");


    //Monstroscity of dealing with input and setting the above variables
    for (int i = 0; i < argc; i++) {
        if (strcmp(argv[i], "-w") == 0) {
            needToGray = 1;

        } else if (strcmp(argv[i], "-b") == 0) {
            char* tempShift;
            if (i + 1 == argc) {
                printf("Invalid # of args. (Usually due to missing vals) Operation not completed.\n");
                return 1;
            }
            tempShift = argv[++i];

            for (int g = 0; g < strlen(tempShift); g++) {
                if (tempShift[g] == '-' && g == 0) {

                } else if (tempShift[g] < '0' || tempShift[g] > '9') {   //https://stackoverflow.com/questions/29248585/c-checking-command-line-argument-is-integer-or-not
                    printf("-b has invalid shift. Operation not completed.\n");
                    return 1;
                }
            }

            blueShift = atoi(tempShift);

        } else if (strcmp(argv[i], "-g") == 0) {
            char* tempShift;
            if (i + 1 == argc) {
                printf("Invalid # of args. (Usually due to missing vals) Operation not completed.\n");
                return 1;
            }

            tempShift = argv[++i];

            for (int g = 0; g < strlen(tempShift); g++) {
                if (tempShift[g] == '-' && g == 0) {

                } else if (tempShift[g] < '0' || tempShift[g] > '9') {   //https://stackoverflow.com/questions/29248585/c-checking-command-line-argument-is-integer-or-not
                    printf("-g has invalid shift. Operation not completed.\n");
                    return 1;
                }
            }

            greenShift = atoi(tempShift);

        } else if (strcmp(argv[i], "-r") == 0) {
            char* tempShift;
            if (i + 1 == argc) {
                printf("Invalid # of args. (Usually due to missing vals) Operation not completed.\n");
                return 1;
            }

            tempShift = argv[++i];

            for (int g = 0; g < strlen(tempShift); g++) {
                if (tempShift[g] == '-' && g == 0) {

                } else if (tempShift[g] < '0' || tempShift[g] > '9') {   //https://stackoverflow.com/questions/29248585/c-checking-command-line-argument-is-integer-or-not
                    printf("r has invalid shift. Operation not completed.\n");
                    return 1;
                }
            }

            redShift = atoi(tempShift);

        } else if (strcmp(argv[i], "-s") == 0) {
            char* tempShift;
            if (i + 1 == argc) {
                printf("Invalid # of args. (Usually due to missing vals) Operation not completed.\n");
                return 1;
            }

            tempShift = argv[++i];  //TODO: FIgure this out: WHY DOES STRCPY NOT WORK HERE :(((
            int decimalCount = 0;

            for (int g = 0; g < strlen(tempShift); g++) {
                if (tempShift[g] == '.') {
                    decimalCount++;
                }

                if (decimalCount > 1) {
                    printf("-s has invalid input. (Multiple decimals) Operation not completed.\n");
                    return 1;
                }

                if ((tempShift[g] < '0' || tempShift[g] > '9') && tempShift[g] != '.') {   //https://stackoverflow.com/questions/29248585/c-checking-command-line-argument-is-integer-or-not
                    printf("-s has invalid input. Operation not completed.\n");
                    return 1;
                }
            }

            scale = atof(tempShift);
        } else if (strcmp(argv[i], "-o") == 0) {
            for (int k = 0; k < 1; k++) {
            char tempFileName[255] = "Empty";
            char copyOfFileName[255];
            if (i + 1 == argc) {
                printf("Invalid # of args. (Usually due to missing vals) Operation not completed.\n");
                return 1;
            }

            strcpy(tempFileName, argv[++i]);
            strcpy(copyOfFileName, tempFileName);

            int decimalCount = 0;

            if (tempFileName[0] == '.') {            //Starting with file extension or just a dot  EHhh doesn't really solve the issue - but I don't think this is required anyway
                printf("-o has invalid input. No extension provided. Using default instead.\n");
                // strcpy(outputFileName, tempFileName);
                // strcat(outputFileName, "_copy.bmp");
                break;
            }

            for (int g = 0; g < strlen(tempFileName); g++) {

                if (tempFileName[g] == '.') {
                    decimalCount++;
                }

                if (decimalCount > 1) {
                    printf("-o has invalid input. (Multiple dots (.))");
                    return 1;
                }
            }

            if (decimalCount == 0) {
                printf("-o has invalid input. No extension provided. Using default instead.\n");
                // strcpy(outputFileName, tempFileName);
                // strcat(outputFileName, "_copy.bmp");
                break;
            }

            //tempFileName = argv[++i];
            char* token;
            char* restofString = tempFileName;

            //Remove file name from the file
            token = strtok_r(restofString, ".", &restofString);

            //Obtain file extension
            strcpy(token, strtok_r(restofString, ".",&restofString));
            if (strcmp(token, "bmp") == 0 && (strtok_r(restofString, ".",&restofString) == NULL)) {
                strcpy(outputFileName, copyOfFileName); //TODO: Check if there's an issue here
            } else {
                strcpy(tempFileName, argv[i]);
                restofString = tempFileName;
                token = strtok_r(restofString, ".", &restofString);
                printf("Invalid file name, using default filename instead.\n");
                // strcpy(outputFileName, token);
                // strcat(outputFileName, "_copy.bmp");
            }

        }
    }
    }

    //Output filename already set, (at beginning or within above code)
    if (needToGray) {
        image_apply_bw(img);
    }

    image_apply_colorshift(img, redShift, greenShift, blueShift);
    image_apply_resize(img,scale);
    makeDIBHeader(&DIB, image_get_width(img), image_get_height(img));
    makeBMPHeader(&BMP, image_get_width(img), image_get_height(img));

    FILE* file_output = fopen(outputFileName, "wb");
    writeBMPHeader(file_output, &BMP);
    writeDIBHeader(file_output, &DIB);
    writePixelsBMP(file_output, image_get_pixels(img), image_get_width(img), image_get_height(img));
    image_destroy(&img);
    fclose(file_output);
    return 0;
}