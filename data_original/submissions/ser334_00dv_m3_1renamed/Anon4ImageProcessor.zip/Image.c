#include <stdio.h>
#include "Image.h"
#include <stdlib.h>

Image* image_create(struct Pixel** pArr, int width, int height) {
    //TODO: Might not need to malloc? Currently memory leak issues
    Image* newImage = (Image*)(malloc(sizeof(Image)));;
    newImage->pArr = pArr;
    newImage->width = width;
    newImage->height = height;
    return newImage;
}

void image_destroy(Image** img) {
    free((*img)->pArr);
    //TODO MAke sure above works correctly
    (*img)->pArr = NULL;
    (*img)->width = 0;
    (*img)->height = 0;

    //TODO: Make sure that below works as intended
    free(*img);
    *img = NULL;
}

struct Pixel** image_get_pixels(Image* img) {
    return img->pArr;
}

int image_get_width(Image* img) {
    return img->width;
}

int image_get_height(Image* img) {
    return img->height;
}


//TODO: Implement
void image_apply_bw(Image* img) {
    // For each pixel in pArr:
    // grayscale = 0.299R + 0.587G + 0.114B


    for (int row = 0; row < img->height; row++) {
        for (int column = 0; column < img->width; column++) {
            double grayScaleVal = (0.299 * img->pArr[row][column].red) +
                                    (0.587 * img->pArr[row][column].green) +
                                       (0.114 * img->pArr[row][column].blue);

            img->pArr[row][column].blue = grayScaleVal;
            img->pArr[row][column].green = grayScaleVal;
            img->pArr[row][column].red = grayScaleVal;
        }
    }

}

void image_apply_colorshift(Image* img, int rShift, int gShift, int bShift) {
    for (int row = 0; row < img->height; row++) {
        for (int column = 0; column < img->width; column++) {

            int newBlue = img->pArr[row][column].blue + bShift;
            if (newBlue > 255) {
                newBlue = 255;
            } else if (newBlue < 0) {
                newBlue = 0;
            }

            int newGreen = img->pArr[row][column].green + gShift;
            if (newGreen > 255) {
                newGreen = 255;
            } else if (newGreen < 0) {
                newGreen = 0;
            }

            int newRed = img->pArr[row][column].red + rShift;
            if (newRed > 255) {
                newRed = 255;
            } else if (newRed < 0) {
                newRed = 0;
            }

            img->pArr[row][column].blue = newBlue;;
            img->pArr[row][column].green = newGreen;
            img->pArr[row][column].red = newRed;
        }
    }
}

void image_apply_resize(Image* img, float factor) {
    int newWidth = img->width * factor;
    int newHeight = img->height * factor;
    double inverseScale = 1/factor;
    struct Pixel** ogPixelArray = img->pArr;

    enum smallOrBig {smallToBig = 0, bigToSmall = 1};
    typedef enum smallOrBig SmallOrBig;

    SmallOrBig direction;
    if (factor < 0) {
        direction = bigToSmall;
    } else if (factor > 0) {
        direction = smallToBig;
    } else {
        printf("ERROR: UNSUPPORTED SCALE FACTOR (0)");
    }

    //Create a new pixel array of correct length and width (rounded to int)
    struct Pixel** newPixelArray = (struct Pixel**)malloc(sizeof(struct Pixel*) * newHeight); // height
    for (int p = 0; p < newHeight; p++) {
        newPixelArray[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * newWidth); //width
    }


    //For each of the pixels in the new pixel array, set the pixel value to the pixel it maps to according to the factor
    for (int row = 0; row < newHeight; row++) {
        for (int column = 0; column < newWidth; column++) {
            if (direction == bigToSmall) { //TODO: Fix this - wrong
                newPixelArray[row][column].blue = ogPixelArray[(int)(row * inverseScale)][(int)(column * inverseScale)].blue;
                newPixelArray[row][column].green = ogPixelArray[(int)(row * inverseScale)][(int)(column * inverseScale)].green;
                newPixelArray[row][column].red = ogPixelArray[(int)(row * inverseScale)][(int)(column * inverseScale)].red;
            } else if (direction == smallToBig) {
                newPixelArray[row][column].blue = ogPixelArray[(int)(row / factor)][(int)(column / factor)].blue;
                newPixelArray[row][column].green = ogPixelArray[(int)(row / factor)][(int)(column / factor)].green;
                newPixelArray[row][column].red = ogPixelArray[(int)(row / factor)][(int)(column / factor)].red;
            }
        }
    }

    free(img->pArr);
    img->pArr = newPixelArray;
    img->width = newWidth;
    img->height = newHeight;
}