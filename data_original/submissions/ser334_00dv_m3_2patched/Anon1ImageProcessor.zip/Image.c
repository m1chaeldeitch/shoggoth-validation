/**
* Handles the input BMP image and its associated struct
*
* Completion time: ?
*
* @author XYZ, Ruben Acuna
* @version 1.0
*/

#include <stdio.h>
#include <stdlib.h>
#include "BMPHandler.h"
#include "Image.h"

/* Creates a new image and returns it.
*
 * @param  pArr: Pixel array of this image.
 * @param  width: Width of this image.
 * @param  height: Height of this image.
 * @return A pointer to a new image.
*/
Image* image_create(struct Pixel** pArr, int width, int height) {
    struct Image* image = malloc(sizeof(struct Image));
    image->width = width;
    image->height = height;
    image->pArr = pArr;

    return image;
}


/* Destroys an image. Does not deallocate internal pixel array.
*
 * @param  img: the image to destroy.
*/
void image_destroy(Image** img) {
    free((*img)->pArr);
    free(*img);
}

/* Returns a double pointer to the pixel array.
*
 * @param  img: the image.
*/
struct Pixel** image_get_pixels(Image* img) {
    return img->pArr;
}

/* Returns the width of the image.
*
 * @param  img: the image.
*/
int image_get_width(Image* img) {
    return img->width;
}

/* Returns the height of the image.
*
 * @param  img: the image.
*/
int image_get_height(Image* img) {
    return img->height;
}

/* Converts the image to grayscale.
*
 * @param  img: the image.
*/
void image_apply_bw(Image* img) {
    struct Pixel** pixels = img->pArr;

    int i,j;
    for(i = 0; i < img->height; i++) {
        for (j = 0; j < img->width; j++) {
            //printf("%d,%d,%d\n", pixels[i][j].red, pixels[i][j].green, pixels[i][j].blue);

            int total = (int)(pixels[i][j].blue * .114 + pixels[i][j].green * .587 + pixels[i][j].red * .299);

            pixels[i][j].red = total;
            pixels[i][j].green = total;
            pixels[i][j].blue = total;
        }
    }
}

/**
 * Shift color of the internal Pixel array. The dimension of the array is width * height.
 * The shift value of RGB is rShift, gShift，bShift. Useful for color shift.
 *
 * @param  img: the image.
 * @param  rShift: the shift value of color r shift
 * @param  gShift: the shift value of color g shift
 * @param  bShift: the shift value of color b shift
 */
void image_apply_colorshift(Image* img, int rShift, int gShift, int bShift) {
    struct Pixel** pixels = img->pArr;

    int i,j;
    for(i = 0; i < img->height; i++) {
        for (j = 0; j < img->width; j++) {
            //printf("%d,%d,%d\n", pixels[i][j].red, pixels[i][j].green, pixels[i][j].blue);
            short r,g,b;

            r = pixels[i][j].red + rShift;
            if(r < 0) r = 0;
            if(r > 255) r = 255;

            g = pixels[i][j].green + gShift;
            if(g < 0) g = 0;
            if(g > 255) g = 255;

            b = pixels[i][j].blue + bShift;
            if(b < 0) b = 0;
            if(b > 255) b = 255;

            pixels[i][j].red = r;
            pixels[i][j].green = g;
            pixels[i][j].blue = b;

        }
    }
}

/**
 * Converts the image to grayscale. If the scaling factor is less than 1 the new image will be
 * smaller, if it is larger than 1, the new image will be larger.
 *
 * @param  img: the image.
 * @param  factor: the scaling factor
*/
void image_apply_resize(Image* img, float factor) {
    int newWidth = (int)(image_get_width(img) * factor);
    int newHeight = (int)(image_get_height(img) * factor);

    struct Pixel** pixels = (struct Pixel**)malloc(sizeof(struct Pixel*) * newHeight);
    for (int p = 0; p < newHeight; p++) {
        pixels[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * newWidth);
    }
    int i, j;
    for (i = 0; i < newHeight; i++) {
        for (j = 0; j < newWidth; j++) {
            int adjI, adjJ;
            adjI = (int) (i * (1 / factor));
            adjJ = (int) (j * (1 / factor));

            pixels[i][j].red = img->pArr[adjI][adjJ].red;
            pixels[i][j].green = img->pArr[adjI][adjJ].green;
            pixels[i][j].blue = img->pArr[adjI][adjJ].blue;
        }
    }
    struct Image* newImg = image_create(pixels, newWidth, newHeight);
    image_destroy(&img);
    *img = *newImg;

}