/**
* Main handler for the program, gets user input and calls functions.
*
* Completion time: 
*
* @author XYZ, Ruben Acuna
* @version 1.0
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "BMPHandler.h"
#include "Image.h"

int main(int argc, char* argv[]) {

    struct BMP_Header* bmpHeader = malloc(sizeof(struct BMP_Header));
    struct DIB_Header* dibHeader = malloc(sizeof(struct DIB_Header));
    struct Image* image;

    char* fileName;
    if(argc <= 1) {
        printf("ERROR: Must specify an input file");
        return 1;
    }

    fileName = argv[1];
    char test[50];
    strcpy(test, argv[1]);
    strtok(test, ".");
    char* ending = strtok(NULL, ".");

    if(strcasecmp(ending, "bmp")) {
        printf("ERROR: Input File Must be .bmp");
        return 1;
    }

    FILE* file = fopen(fileName, "rb");
    if(file == NULL) {
        printf("FILE %s NOT FOUND", fileName);
        return 1;
    }



    readBMPHeader(file, bmpHeader);
    readDIBHeader(file, dibHeader);

    struct Pixel** pixels = (struct Pixel**)malloc(sizeof(struct Pixel*) * dibHeader->height);
    for (int p = 0; p < dibHeader->height; p++) {
        pixels[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * dibHeader->width);
    }
    image = image_create(pixels, dibHeader->width, dibHeader->height);
    readPixelsBMP(file, pixels, image_get_width(image), image_get_height(image));


    printf("\n");
    fclose(file);

    int c,bw = 0,r = 0,g = 0,b = 0;
    float size = 1;
    char* outputFile;
    char* str;
    while ((c = getopt (argc, argv, ":wr:g:b:s:o:")) != -1) {
        switch (c) {
            case 'w':
                bw = 1;
                break;
            case 'r':
                r = strtol(optarg, &str, 10);
                if(strlen(str) > 0) {
                    printf("ERROR: r is not an integer");
                    return 1;
                }
                break;
            case 'g':
                g = strtol(optarg, &str, 10);
                if(strlen(str) > 0) {
                    printf("ERROR: g is not an integer");
                    return 1;
                }
                break;
            case 'b':
                b = strtol(optarg, &str, 10);
                if(strlen(str) > 0) {
                    printf("ERROR: b is not an integer");
                    return 1;
                }
                break;
            case 's':
                size = strtof(optarg, &str);
                if(strlen(str) > 0) {
                    printf("ERROR: size is not a float");
                    return 1;
                }
                break;
            case 'o':
                strcpy(test, optarg);
                strtok(test, ".");
                char* ending = strtok(NULL, ".");

                if(strcasecmp(ending, "bmp")) {
                    printf("ERROR: Output File Must be .bmp");
                    return 1;
                }

                outputFile = optarg;
                break;
            case '?':
                printf("Unrecognized Option %c\n", optopt);
                break;
        }
    }
    if(bw) image_apply_bw(image);
    image_apply_colorshift(image, r,g,b);
    if(outputFile == NULL) outputFile = strcat(strtok(fileName, "."),"_COPY.bmp");

    struct BMP_Header* newBMP;
    struct DIB_Header* newDIB;

    if(size != 1) {
        newBMP = malloc(sizeof(struct BMP_Header));
        newDIB = malloc(sizeof(struct DIB_Header));

        int newWidth = (int)(image_get_width(image) * size);
        int newHeight = (int)(image_get_height(image) * size);
        //printf("Width:%d, height:%d\n", newWidth, newHeight);

        makeBMPHeader(newBMP, newWidth, newHeight);
        makeDIBHeader(newDIB, newWidth, newHeight);

        //assign things that are based on input image here
        newBMP->offset_pixel_array = bmpHeader->offset_pixel_array;

        newDIB->header_size = dibHeader->header_size;
        newDIB->bitsPerPixel = dibHeader->bitsPerPixel;
        newDIB->imageSize = newWidth * newHeight * dibHeader->bitsPerPixel;

        image_apply_resize(image, size);
    }

    FILE* file_output = fopen(outputFile, "wb");
    if(size == 1) {
        writeBMPHeader(file_output, bmpHeader);
        writeDIBHeader(file_output, dibHeader);
    } else {
        writeBMPHeader(file_output, newBMP);
        writeDIBHeader(file_output, newDIB);
    }
    writePixelsBMP(file_output, image_get_pixels(image), image_get_width(image), image_get_width(image));

    fclose(file_output);
    image_destroy(image);
    free(bmpHeader);
    free(dibHeader);
    free(newBMP);
    free(newDIB);

    printf("Image Creation Complete!\n");
}