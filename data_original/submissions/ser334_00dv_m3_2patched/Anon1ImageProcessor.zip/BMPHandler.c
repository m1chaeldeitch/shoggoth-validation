/**
* Handles the headers of the input BMP file and their associated structs.
*
* Completion time: 
*
* @author XYZ, Ruben Acuna
* @version 1.0
*/

#include <stdio.h>
#include <stdlib.h>
#include "BMPHandler.h"
#include "Image.h"

/**
 * Read BMP header of a BMP file.
 *
 * @param  file: A pointer to the file being read
 * @param  header: Pointer to the destination BMP header
 */
void readBMPHeader(FILE* file, struct BMP_Header* header) {

    fread(&header->signature, sizeof(char) * 2, 1, file);
    fread(&header->size, sizeof(int), 1, file);
    fread(&header->reserved1, sizeof(short), 1, file);
    fread(&header->reserved2, sizeof(short), 1, file);
    fread(&header->offset_pixel_array, sizeof(int), 1, file);
}

/**
 * Write BMP header of a file. Useful for creating a BMP file.
 *
 * @param  file: A pointer to the file being written
 * @param  header: The header to write to the file
 */
void writeBMPHeader(FILE* file, struct BMP_Header* header) {

    //printf("sig: %c%c, size: %d, reserved1 %d, reserved2 %d, offset: %d", header->signature[0], header->signature[1],
    //       header->size, header->reserved1, header->reserved2, header->offset_pixel_array);

    fwrite(&header->signature, sizeof(char) * 2, 1, file);
    fwrite(&header->size, sizeof(int), 1, file);
    fwrite(&header->reserved1, sizeof(short), 1, file);
    fwrite(&header->reserved2, sizeof(short), 1, file);
    fwrite(&header->offset_pixel_array, sizeof(int), 1, file);
}

/**
 * Read DIB header from a BMP file.
 *
 * @param  file: A pointer to the file being read
 * @param  header: Pointer to the destination DIB header
 */
void readDIBHeader(FILE* file, struct DIB_Header* header) {
    fread(&header->header_size, sizeof(int),1,file);
    fread(&header->width, sizeof(int),1,file);
    fread(&header->height, sizeof(int),1,file);
    fread(&header->planes, sizeof(short),1,file);
    fread(&header->bitsPerPixel, sizeof(short),1,file);
    fread(&header->compression, sizeof(int),1,file);
    fread(&header->imageSize, sizeof(int),1,file);
    fread(&header->xPixelsMeter, sizeof(int),1,file);
    fread(&header->yPixelsMeter, sizeof(int),1,file);
    fread(&header->colorTable, sizeof(int),1,file);
    fread(&header->importantColorCount, sizeof(int),1,file);

}

/**
 * Write DIB header of a file. Useful for creating a BMP file.
 *
 * @param  file: A pointer to the file being written
 * @param  header: The header to write to the file
 */
void writeDIBHeader(FILE* file, struct DIB_Header* header) {
    //printf("\nheaderSize: %d, width: %d, height: %d, bitsPerPixel: %d\n", header->header_size, header->width, header->height, header->imageSize);
    fwrite(&header->header_size, sizeof(int),1,file);
    fwrite(&header->width, sizeof(int),1,file);
    fwrite(&header->height, sizeof(int),1,file);
    fwrite(&header->planes, sizeof(short),1,file);
    fwrite(&header->bitsPerPixel, sizeof(short),1,file);
    fwrite(&header->compression, sizeof(int),1,file);
    fwrite(&header->imageSize, sizeof(int),1,file);
    fwrite(&header->xPixelsMeter, sizeof(int),1,file);
    fwrite(&header->yPixelsMeter, sizeof(int),1,file);
    fwrite(&header->colorTable, sizeof(int),1,file);
    fwrite(&header->importantColorCount, sizeof(int),1,file);
}

/**
 * Make BMP header based on width and height. Useful for creating a BMP file.
 *
 * @param  header: Pointer to the destination DIB header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makeBMPHeader(struct BMP_Header* header, int width, int height) {
    //header = malloc(sizeof(struct BMP_Header));
    header->signature[0] = 'B';
    header->signature[1] = 'M';
    header->size = width * height * 3 + 54;
    header->reserved1 = 0;
    header->reserved2 = 0;


    //header->offset_pixel_array = 54;
}

/**
* Make new DIB header based on width and height.Useful for creating a BMP file.
*
* @param  header: Pointer to the destination DIB header
* @param  width: Width of the image that this header is for
* @param  height: Height of the image that this header is for
*/
void makeDIBHeader(struct DIB_Header* header, int width, int height) {
    //header = malloc(sizeof(struct DIB_Header));

    header->width = width;
    header->height = height;
    header->planes = 1;
    header->compression = 0;
    //header->imageSize = width * height * 3;
    header->xPixelsMeter = 3780;
    header->yPixelsMeter = 3780;
    header->colorTable = 0;
    header->importantColorCount = 0;

}

/**
 * Read Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read
 * @param  pArr: Pixel array to store the pixels being read
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
void readPixelsBMP(FILE* file, struct Pixel** pArr, int width, int height) {
    int i,j,pad;

    for(i = 0; i < height; i++) {
        for(j = 0; j < width; j++) {
            //struct Pixel *pixel = malloc(sizeof(struct Pixel));
            unsigned char r,g,b;
            fread(&b, sizeof(char), 1, file);
            fread(&g, sizeof(char), 1, file);
            fread(&r, sizeof(char), 1, file);

            pArr[i][j].red = r;
            pArr[i][j].green = g;
            pArr[i][j].blue = b;

        }
        pad = 4 - (width % 4);
        if(pad != 4) fseek(file, sizeof(unsigned char) * pad, SEEK_CUR);
    }
}

/**
 * Write Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image to write to the file
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
void writePixelsBMP(FILE* file, struct Pixel** pArr, int width, int height) {
    int i,j,pad;
    //printf("%d,%d",height,width);
    for(i = 0; i < height; i++) {
        for(j = 0; j < width; j++) {
            fwrite(&pArr[i][j].blue, sizeof(char), 1, file);
            fwrite(&pArr[i][j].green, sizeof(char), 1, file);
            fwrite(&pArr[i][j].red, sizeof(char), 1, file);

        }
        pad = width % 4;
        fseek(file, sizeof(unsigned char) * pad, SEEK_CUR);
    }


}